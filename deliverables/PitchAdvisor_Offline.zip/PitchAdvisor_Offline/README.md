# PitchAdvisor TW 本機斷網展示包

這個資料夾包含已編譯的網頁、真實模型推論程式、凍結模型、固定示範案例及評估報告。
**不包含 Python、第三方套件或虛擬環境。** 必須先在有網路時準備 Python 3.12 與 requirements-lock.txt 的 runtime 套件；既有專案的 .venv 可直接使用。
不需要 Node、Supabase、Render 或任何 .env 憑證來執行本包。

在 PowerShell 中進入解壓縮後的 PitchAdvisor_Offline 資料夾：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/Start-Offline.ps1 -PythonExe "C:\完整路徑\Python環境\Scripts\python.exe"
```

開啟 http://127.0.0.1:8765/。任意合法情境由本機模型即時計算；若切換固定案例頁，則是明確標示的已計算案例。

停止：`powershell -ExecutionPolicy Bypass -File scripts/Stop-Offline.ps1`。
前景執行也可用：`<Python路徑> scripts/serve_offline.py --port 8765`，按 Ctrl+C 結束。

完整準備、版本查核與斷網演練：[OFFLINE_GUIDE.md](docs/week3/OFFLINE_GUIDE.md)。
資料來源：Rebas 野球革命 Open Data（ODC-By），授權副本位於 docs/sources/REBas-LICENSE。
模型與最終測試限制請閱讀 docs/week3/FINAL_RESULTS.md。
