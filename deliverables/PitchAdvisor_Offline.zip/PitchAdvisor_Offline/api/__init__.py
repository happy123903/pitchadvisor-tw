"""PitchAdvisor FastAPI application."""
